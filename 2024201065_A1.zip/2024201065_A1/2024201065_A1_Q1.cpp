#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <cerrno>
#include <cstring>
#include <iostream> 
#include <string> 

#ifndef BUF_SIZE 
#define BUF_SIZE 8192
#endif
using namespace std; 
 
void create_directory(const string& vatsal_0731) {
    
    if (mkdir(vatsal_0731.c_str(), 00700) == -1) {
        if (EEXIST == errno) {
             write(1,"directory already exists", 24) ;
        }
        else{
            write(1 ,"error in creating directory", 27);
            exit(1) ;
        } 
    } 
    else {
        write(1,"directory is successfully created", 33) ;
    }
}
int main(int argc, char* argv[])
{   
    char* input_file = argv[1];
    int flags = stoi(argv[2]);

    if((flags==0 && argc !=3) || (flags==1 && argc!=5)){
        write(1 ,"parameters not passed correctly : " , 34 ) ;
        return EXIT_FAILURE ;
    } 


    create_directory("Assigement1") ;
    const char* path1 ;
    if(flags==0){
        path1 = "Assigement1/0_" ;
    }
    else if(flags==1){
        path1 = "Assigement1/1_" ;
    } 

    // to save the file in directory

    int len = strlen(argv[1]) ;
    char* concat = new char[len+15] ;
    strcat(concat,path1) ;
    strcat(concat,argv[1]) ;
    
    int fd_input = open(input_file,O_RDONLY);
    if(fd_input == -1){
        write(1," error occured :", 16);
        perror("open") ;
    }
    
    
    int fd_output = open(concat, O_WRONLY  | O_CREAT | O_TRUNC , 0600) ; 
    if(fd_output == -1){
        write(1," error occured :", 16);
        perror("open") ;
    }
     
    if(flags!=0 && flags!=1){
        write(1 , " error : wrong input of flags on commond line",45);
        exit(1) ;
    }

    char buffer[BUF_SIZE];
    long long pte = lseek(fd_input , 0 , SEEK_END) ;
    char temp[BUF_SIZE];
    long long curr =  0 ;
    long long total = pte ;
    if(flags==0){
        string s  ;
        char *p ;
        long long n=1;
        while(pte>0){
           
            if(pte-BUF_SIZE<0){
                 int n = lseek(fd_input,0,SEEK_SET);
                 int bytes = read(fd_input,buffer,pte);
                 for(int i=0 ; i<bytes ; i++){
                    temp[i] = buffer[bytes-1-i] ;
                }
                 write(fd_output,temp, bytes);
                 curr += bytes ;
                 s = "\r percentage of file writtten : " + to_string(curr*100/total)+"%" ;
                 p = &s[0];
                 write(1, p, s.length());
                 break;
            } 

            int long long last = lseek(fd_input , -(n*BUF_SIZE) , SEEK_END) ;
            n++;
            int bytes = read(fd_input,buffer,BUF_SIZE);
           
            for(int i=0 ; i<BUF_SIZE ; i++){
                temp[i] = buffer[BUF_SIZE-i-1];
            }
             write(fd_output,temp, bytes);
             curr += bytes ;
              s = "\r percentage of file written : " + to_string(curr*100/total)+"%" ;
                 p = &s[0];
                 write(1, p, s.length());
             pte -= bytes ;
        }
    }
    
    if(flags==1){
        string s ;
        char* p ;
        int start = stoi(argv[3]) ;
        int end = stoi(argv[4]) ;
         if(start > end){
            write(2,"error : start index should be less than end index" ,49) ;
            exit(1) ;
         }
         if(start < 0 ){
            write(2,"error : start index is less than file size " ,43) ;
            exit(1) ;
         }
        if(start >= pte ){
            write(2,"error : start index is greater than file size " ,46) ;
            exit(1) ;
         }
        if(end < 0 ){
            write(2,"error : end index is less than file size " ,41) ;
            exit(1) ;
         }
        if(end >= pte ){
            write(2,"error : end index is greater than file size " ,44) ;
            exit(1) ;
         }
        // from 1->start      
        
        int n=1;
        long long cstart= lseek(fd_input,start,SEEK_SET);
        while(cstart>0){
            
            if(cstart-BUF_SIZE<0){
                 int n = lseek(fd_input,0,SEEK_SET);

                 int bytes = read(fd_input,buffer,cstart);
                 for(int i=0 ; i<bytes ; i++){
                    temp[i] = buffer[bytes-1-i] ;
                }
                 write(fd_output,temp, bytes);
                 curr += bytes ;
                 s = "\r percentage of file writtten : " + to_string(curr*100/total)+"%" ;
                 p = &s[0];
                 write(1, p, s.length());
                 break;
            } 
            
            lseek(fd_input , -n*BUF_SIZE , SEEK_CUR) ;
            n++ ;
            int bytes = read(fd_input,buffer,BUF_SIZE);
            lseek(fd_input,start,SEEK_SET); 
            for(int i=0 ; i<BUF_SIZE ; i++){
                temp[i] = buffer[BUF_SIZE-i-1];
            }
             write(fd_output,temp, bytes);
             curr += bytes ;
              s = "\r percentage of file writtten : " + to_string(curr*100/total)+"%" ;
                 p = &s[0];
                 write(1, p, s.length());
             cstart -= bytes ;   
    }
       
       // from start to end 
      
       int dif = end-start+1 ;
       int pointing = lseek(fd_input,start,SEEK_SET);
       while(dif>0){
           if(dif<BUF_SIZE){
            
            read(fd_input,buffer , dif );
            for(int i=0 ; i<BUF_SIZE ; i++){
                temp[i] = buffer[i] ;
            }
            write(fd_output, temp , dif) ;
            curr += dif ;
             s = "\r percentage of file writtten : " + to_string(curr*100/total)+"%" ;
                 p = &s[0];
                 write(1, p, s.length());
            break ;
           }
            int bytes = read(fd_input , buffer ,BUF_SIZE) ;
            for(int i=0 ; i<BUF_SIZE ; i++){
                temp[i] = buffer[i] ;
            }
            write(fd_output, temp , BUF_SIZE) ;
            curr += BUF_SIZE ;
             s = "\r percentage of file writtten : " + to_string(curr*100/total)+"%" ;
                 p = &s[0];
                 write(1, p, s.length());
            dif = dif-BUF_SIZE ;
        }
        
      // from endindex->end
         
         n=1 ;
         int dif1 = pte-end-1 ;
         lseek(fd_input , 0 , SEEK_END) ;
         while(dif1>0){
            if(dif1<BUF_SIZE){
                
                lseek(fd_input , -dif1-(n-1)*BUF_SIZE , SEEK_END ) ;
                int bytes = read(fd_input , buffer , dif1) ;
                
                for(int i=0 ; i<bytes ; i++){
                temp[i] = buffer[bytes-i-1] ;
            }
             
             write(fd_output , temp , bytes ) ;
             curr += bytes ;
              s = "\r percentage of file writtten : " + to_string(curr*100/total)+"%" ;
                 p = &s[0];
                 write(1, p, s.length());
             break ;
            }
            lseek(fd_input,-(n*BUF_SIZE) , SEEK_END ) ;
            n++ ;
            int bytes = read(fd_input , buffer , BUF_SIZE) ;
            for(int i=0 ; i<BUF_SIZE ; i++){
                temp[i] = buffer[BUF_SIZE-i-1] ;
            }
            write(fd_output , temp , BUF_SIZE);
            curr += BUF_SIZE ;
             s = "\r percentage of file writtten : " + to_string(curr*100/total)+"%" ;
             p = &s[0];
             write(1, p, s.length());
            dif1 = dif1 - BUF_SIZE ;
         }

         close(fd_input) ;
         close(fd_output) ;
    return 0;
    }
}