#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <cerrno>
#include <cstring>
#include <iostream> 
#include <string>

#ifndef BUF_SIZE 
#define BUF_SIZE 8192
#endif
using namespace std;

void permission_for_file(mode_t permission , string s){
     string msg =  "User has read permissions on "+s+" : " + (permission & S_IRUSR ? "Yes" : "No")+"\n"; 
     write(1,&msg[0], strlen(&msg[0]) ) ;   

     msg =  "User has write permissions on "+s+" : " + (permission & S_IWUSR ? "Yes" : "No")+"\n"; 
     write(1,&msg[0], strlen(&msg[0]) ) ;   

     msg =  "User has execute permissions on "+s+" : " + (permission & S_IXUSR ? "Yes" : "No")+"\n"; 
     write(1,&msg[0], strlen(&msg[0]) ) ;   

     msg =  "Group has read permissions on "+s+" : " + (permission & S_IRGRP ? "Yes" : "No")+"\n"; 
     write(1,&msg[0], strlen(&msg[0]) ) ;   

     msg =  "Group has write permissions on "+s+" : " + (permission & S_IWGRP ? "Yes" : "No")+"\n"; 
     write(1,&msg[0], strlen(&msg[0]) ) ;   

     msg =  "Group has execute permissions on "+s+" : " + (permission & S_IXGRP ? "Yes" : "No")+"\n"; 
     write(1,&msg[0], strlen(&msg[0]) ) ;   

     msg =  "other has read permissions on "+s+" : " + (permission & S_IROTH ? "Yes" : "No")+"\n"; 
     write(1,&msg[0], strlen(&msg[0]) ) ;   

     msg =  "Other has write permissions on "+s+" : " + (permission & S_IWOTH ? "Yes" : "No")+"\n"; 
     write(1,&msg[0], strlen(&msg[0]) ) ;   

     msg =  "Other has execute permissions on "+s+" : " + (permission & S_IXOTH ? "Yes" : "No")+"\n"; 
     write(1,&msg[0], strlen(&msg[0]) ) ;   
}

int main(int argc, char *argv[])
{
    if(argc != 4 ){
        write(1," Misconfigured Parameter ",25) ;
        exit(1);

    }

    char* directory = argv[3] ;
    char* input_file = argv[2]; 
    char* output_file = argv[1];
    
    struct stat obj   ;
    
    int d = stat(argv[3],&obj) ;
    if(d==0){
        write(1,"Directory is created : YES\n",27);
    }
    else{
        write(1,"Directory is created : NO\n",26);
    }
    
    char buffer[BUF_SIZE];
    char temp1[BUF_SIZE];
    char temp2[BUF_SIZE] ;

    long long n = 1 ;
    long long k = 0 ;

    int fd_input = open(input_file,O_RDONLY);
    int fd_output = open(output_file,O_RDONLY);

    long long sizeof_inputfile = lseek(fd_input , 0 , SEEK_END) ;
    long long sizeof_outputfile = lseek(fd_output , 0 , SEEK_END) ;
    

    if(sizeof_inputfile!= sizeof_outputfile){
            write(2,"input and output files have different size : YES\n",49) ;
              }
    else{
        write(2,"input and output files have same size : YES\n",44) ; 
         }

    while (sizeof_outputfile>0)
    {   
        if(sizeof_outputfile - BUF_SIZE<0){

            lseek(fd_input , k*BUF_SIZE , SEEK_SET) ;
            int bytes = read(fd_input , temp2 , sizeof_outputfile) ;
            lseek(fd_output , 0 , SEEK_SET) ;
            read(fd_output, temp1 , sizeof_outputfile ) ;
            

            for(int i =0 ; i < bytes ; i++){
                if(temp1[bytes-i-1]!=temp2[i]){
                    write(2,"error in reversing the string ",30) ;
                    exit(1);
                }
            }
            break ;

        }
            lseek(fd_output , -(n*BUF_SIZE) , SEEK_END) ;
            n++;
            read(fd_output,buffer,BUF_SIZE) ;
            for(int i=0 ; i<BUF_SIZE ; i++){
                temp1[i] = buffer[BUF_SIZE-i-1];
            }
            lseek(fd_input , (k*BUF_SIZE) , SEEK_SET ) ;
            k++ ;
            read(fd_input, temp2 , BUF_SIZE) ;
            for(int i=0 ; i<BUF_SIZE ; i++){
                if(temp1[i]!=temp2[i]){
                    write(2,"error in reversing the string ",30) ;
                    exit(1);
                }
            }
            sizeof_outputfile -= BUF_SIZE ;
        }
        write(1 ,"files are reversed : YES\n" ,25) ;

        stat(argv[1],&obj) ;
        permission_for_file(obj.st_mode , "oldfile") ;
        stat(argv[2],&obj) ;
        permission_for_file(obj.st_mode , "newfile") ;
        stat(argv[3],&obj) ;
        permission_for_file(obj.st_mode , "Directory") ;
         
        close(fd_input) ;
        close(fd_output) ;
    return 0;
}


