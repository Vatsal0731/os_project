firstly extract the zip file 2024201065_A1

     Question 1) compile the code using  
     c++ -o 2024201065_A1_Q1 2024201065_A1_Q1.cpp 
     give the paramters on command line 
     for flag = 0 input will be <file name> <flag value> 
     for flag = 1 input wille be <file name> <start index> <end index>

     Question 2 ) compile the code using 
     c++ -o 2024201065_A1_Q2 2024201065_A1_Q2.cpp 
     give parameter on command line as <outfile> <input file> <directory> 
